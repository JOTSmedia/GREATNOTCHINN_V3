# Great Notch Inn — website (upload copy)
One-page static site for thegreatnotchinn.com. Contents: index.html, css/, js/, images/, favicon.ico, robots.txt, sitemap.xml, .htaccess.
Built from clients/Great_Notch_Inn per its DEPLOY.md (tools/, scratch/, docs excluded). Not deployed yet.
## Upload
- GitHub: create a repo, upload all files in this folder (drag-drop in the web UI or `git init && git add . && git commit && git push`). Enable Pages (Settings → Pages → main / root) if hosting there.
- GoDaddy (the live host): upload to public_html. **Merge .htaccess — do not overwrite** the live one. Settle TODO-JOHN items first (see DEPLOY.md in the source folder).
